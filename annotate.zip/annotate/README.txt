This is a plugin developed to annotate satellite images using QGIS. The plugin create images and annotation files for training a Yolo model ( Tested for v2,v3 and v4). You can find the latest version of QGIS here : https://qgis.org/en/site/.

How it works ?:
   1. You can install the plugin using "Install Plugin from zip file" under Plugins -> Manage and Install Plugin. 
   2. Choose the location where you want to save the images and annotation file.
   3. Click on Save and Next, after annotating at a particular location.
   4. Click on Empty to save an image without any annotations.

If you need help or more information contact me at :- sonud13157@gmail.com
