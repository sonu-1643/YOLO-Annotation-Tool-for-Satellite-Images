#!/usr/bin/python
# -*- coding: utf-8 -*-

"""
/***************************************************************************
 annotate
                                 A QGIS plugin
 This plugin can be used to collect and annotate satellite imagery for training a YOLO network
                              -------------------
        begin                : 2020-04-21
        git sha              : $Format:%H$
        copyright            : (C) 2020 by sonu dileep
        email                : sonudilp@colostate.edu
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, \
    Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction

# Initialize Qt resources from file resources.py

from .resources import *
from qgis.core import QgsRectangle, QgsFeature, QgsVectorLayer, \
    QgsPoint, QgsGeometry, QgsMapSettings

# Import the code for the DockWidget

from .annotate_dockwidget import annotateDockWidget
import os.path
import time

from string import capwords

from qgis.PyQt import QtGui, uic
from qgis.PyQt.QtCore import Qt, QFileInfo
from qgis.PyQt.QtWidgets import QMessageBox, QFrame, QDialog, \
    QFileDialog

from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, \
    Qt
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from .draw_rect import *

from qgis.core import QgsProject
from qgis.gui import *
from qgis.PyQt.QtWidgets import QAction, QMainWindow
from qgis.PyQt.QtCore import Qt

from qgis.gui import QgsMapTool, QgsRubberBand, QgsMapToolEmitPoint, \
    QgsProjectionSelectionDialog
from qgis.core import QgsWkbTypes, QgsPointXY

from qgis.PyQt.QtCore import Qt, QCoreApplication, pyqtSignal, QPoint, \
    QSize
from qgis.PyQt.QtWidgets import QDialog, QLineEdit, QDialogButtonBox, \
    QGridLayout, QLabel, QGroupBox, QVBoxLayout, QComboBox, \
    QPushButton, QInputDialog
from qgis.PyQt.QtGui import QDoubleValidator, QIntValidator, \
    QKeySequence

import math
from qgis.PyQt.QtGui import QColor, QImage, QPainter
from qgis.core import *
import qgis.utils
import csv


class annotate:

    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """

        # Save reference to the QGIS interface

        self.iface = iface

        # initialize plugin directory

        self.plugin_dir = os.path.dirname(__file__)

        # initialize locale

        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(self.plugin_dir, 'i18n',
                                   'annotate_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes

        self.actions = []
        self.menu = self.tr(u'&annotate')

        # TODO: We are going to let the user set this up in a future iteration

        self.toolbar = self.iface.addToolBar(u'annotate')
        self.toolbar.setObjectName(u'annotate')

        # print "** INITIALIZING annotate"

        self.pluginIsActive = False
        self.dockwidget = None

        # newly added

        self.i = 0  # keep track of number of images

        self.layer_count = [  # to track number of layers for each label in current canvas
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            ]
        self.location = '/home/sonu/Desktop'  # default folder to save data
        self.tool = None
        self.item = []
        self.item2 = None
        self.name = ' '  # to get the name of the last layer for undo action
        self.orig_layer_name = []  # name of the layers as in qgis
        self.map_layers = [  # equipment names
            'wp_1',
            'wp_tank_oil',
            'wp_tank_water',
            'wp_separator',
            'wp_combustor',
            'wp_compressor',
            'wp_WH_gas_lift',
            'wp_WH_pump_jack',
            'wp_flare',
            'wp_dehydrator',
            'compressor_station',
            'cs_tank_oil',
            'cs_tank_water',
            'cs_separator',
            'cs_combustor',
            'cs_compressor',
            'cs_flare',
            'cs_dehydrator',
            ]

    # noinspection PyMethodMayBeStatic

    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """

        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass

        return QCoreApplication.translate('annotate', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=True,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None,
        ):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            self.toolbar.addAction(action)

        if add_to_menu:
            self.iface.addPluginToMenu(self.menu, action)

        self.actions.append(action)

        return action

    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""

        icon_path = ':/plugins/annotate/icon.png'
        self.add_action(icon_path, text=self.tr(u''),
                        callback=self.run,
                        parent=self.iface.mainWindow())

    # --------------------------------------------------------------------------

    def onClosePlugin(self):
        """Cleanup necessary items here when plugin dockwidget is closed"""

        # print "** CLOSING annotate"

        # disconnects

        self.dockwidget.closingPlugin.disconnect(self.onClosePlugin)

        # remove this statement if dockwidget is to remain
        # for reuse if plugin is reopened
        # Commented next statement since it causes QGIS crashe
        # when closing the docked window:
        # self.dockwidget = None

        self.pluginIsActive = False

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""

        # print "** UNLOAD annotate"

        for action in self.actions:
            self.iface.removePluginMenu(self.tr(u'&annotate'), action)
            self.iface.removeToolBarIcon(action)

        # remove the toolbar

        del self.toolbar

    def select_folder(self):
        """Function to choose a location when pushbutton is pressed"""

        folder = QFileDialog.getExistingDirectory(self.dockwidget,
                'Select output file ', '/home')
        self.location = folder
        self.dockwidget.lineEdit.setText(folder)
        temp_loc = self.location + '/.info.txt'
        if os.path.isfile(temp_loc):
            f = open(temp_loc, 'r')  # to track image count
            self.i = self.i + int(f.read())

        # to create a csv file

        temp_loc = self.location + '/' + 'Data_well_pad.csv'
        if not os.path.isfile(temp_loc):
            with open(temp_loc, 'w+') as csvfile:  # creating a csv file
                filewriter = csv.writer(csvfile, delimiter=',',
                        quotechar='|', quoting=csv.QUOTE_MINIMAL)
                filewriter.writerow([
                    'Item name',
                    'X1',
                    'Y1',
                    'X2',
                    'Y2',
                    'Latitude_1',
                    'Longitude_1',
                    'Latitude_2',
                    'Longitude_2',
                    'Latitude Center',
                    'Longitude Center',
                    ])

    def save_data(self):
        """To save data for annotation and collection"""

        self.i = self.i + 1  # to track image count

        # save image from canvas

        map = self.iface.mapCanvas().extent()
        img_name = self.location + '/' + 'image_' + str(self.i)
        x = {}  # Dictionary to store coordinates of each annotations
        x['map'] = [map.xMinimum(), map.yMaximum(), map.xMaximum(),
                    map.yMinimum()]

        layers = QgsProject.instance().mapLayers()
        for (name, layer) in layers.items():
            for j in range(len(self.map_layers)):
                if self.map_layers[j] in name:
                    l = layer.extent()
                    x[name] = [l.xMinimum(), l.yMaximum(),
                               l.xMaximum(), l.yMinimum()]

        file_name = '/' + 'save_data' + '.txt'
        self.write_dict_to_file(x, file_name)
        file_name = '/' + 'image_' + str(self.i) + '.txt'
        self.write_for_yolo(x, file_name)
        self.reset_1()
        self.layer_count = [  # reset to zero
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            ]
        temp_loc = self.location + '/.info.txt'
        f = open(temp_loc, 'w+')
        f.write(str(self.i))
        self.save_image_sub()
        self.iface.mapCanvas().refresh()

    def save_image_sub(self):
        """Saves the image from current map canvas"""

        map = self.iface.mapCanvas().extent()
        img_name = self.location + '/' + 'image_' + str(self.i)
        height = qgis.utils.iface.mapCanvas().size().height()
        width = qgis.utils.iface.mapCanvas().size().width()
        img = QImage(QSize(width, height),
                     QImage.Format_ARGB32_Premultiplied)

    # set background color

        color = QColor(255, 255, 255)
        img.fill(color.rgb())

    # create painter

        p = QPainter()
        p.begin(img)
        p.setRenderHint(QPainter.Antialiasing)

    # create map settings

        ms = QgsMapSettings()
        ms.setBackgroundColor(color)

    # set layers to render

        layer = QgsProject.instance().mapLayersByName('google_satellite'
                )
        ms.setLayers([layer[0]])

    # set extent

        rect = QgsRectangle(map.xMinimum(), map.yMinimum(),
                            map.xMaximum(), map.yMaximum())

        # rect.scale(1)

        ms.setExtent(rect)

    # set ouptut size

        ms.setOutputSize(img.size())

    # setup qgis map renderer

        render = QgsMapRendererCustomPainterJob(ms, p)
        render.start()
        render.waitForFinished()
        p.end()

    # save the image

        img.save(img_name + '.png')

    def convert_lat_lon(self, a):
        """Converts the coordinate system to latitude and longtide"""

        lon1 = a[0] * 180 / 20037508.34
        lat1 = math.atan(math.exp(a[1] * math.pi / 20037508.34)) * 360 \
            / math.pi - 90
        lon2 = a[2] * 180 / 20037508.34
        lat2 = math.atan(math.exp(a[3] * math.pi / 20037508.34)) * 360 \
            / math.pi - 90
        return [lon1, lat1, lon2, lat2]

    def convert_lat_lon_center(self, a):
        """Finds the center of bounding box and returns latitude and longitude coordinates"""

        x = (a[0] + a[2]) / 2
        y = (a[1] + a[3]) / 2
        lon1 = x * 180 / 20037508.34
        lat1 = math.atan(math.exp(y * math.pi / 20037508.34)) * 360 \
            / math.pi - 90
        return [lon1, lat1]

    def write_dict_to_file(self, dictionary, file_name):
        """Save the location coordinates to a CSV File"""

        for (key, value) in dictionary.items():
            for j in range(len(self.map_layers)):
                if self.map_layers[j] in key:
                    a = self.convert_lat_lon(dictionary[key])
                    b = self.convert_lat_lon_center(dictionary[key])
                    temp_loc = self.location + '/' + 'Data_well_pad.csv'
                    with open(temp_loc, 'a+') as csvfile:  # creating a csv file
                        filewriter = csv.writer(csvfile, delimiter=',',
                                quotechar='|',
                                quoting=csv.QUOTE_MINIMAL)
                        filewriter.writerow([
                            self.map_layers[j],
                            dictionary[key][0],
                            dictionary[key][1],
                            dictionary[key][2],
                            dictionary[key][3],
                            a[0],
                            a[1],
                            a[2],
                            a[3],
                            b[0],
                            b[1],
                            ])
        with open(temp_loc, 'a+') as csvfile:
            filewriter = csv.writer(csvfile, delimiter=',',
                                    quotechar='|',
                                    quoting=csv.QUOTE_MINIMAL)
            filewriter.writerow('\n')

    def write_for_yolo(self, dictionary, file_name):
        """Save the annotation files required for training YOLO models"""

        save_loc = self.location + file_name
        f = open(save_loc, 'w+')
        for (key, value) in dictionary.items():
            for j in range(len(self.map_layers)):
                if self.map_layers[j] in key:
                    f.write(str(j))
                    f.write(' ')
                    temp = self.yolo_conversion(dictionary['map'],
                            dictionary[key])
                    f.write(str(temp[0]))
                    f.write(' ')
                    f.write(str(temp[1]))
                    f.write(' ')
                    f.write(str(temp[2]))
                    f.write(' ')
                    f.write(str(temp[3]))
                    f.write('\n')
        f.close()

    def yolo_conversion(self, map_coordinate, rectangle_coordinate):
        """ Convert to standard image plane coordinate system"""

        x_0 = map_coordinate[0]
        y_0 = map_coordinate[1]
        x_new0 = abs(rectangle_coordinate[0] - x_0)
        y_new0 = abs(rectangle_coordinate[1] - y_0)
        x_new1 = abs(rectangle_coordinate[2] - x_0)
        y_new1 = abs(rectangle_coordinate[3] - y_0)
        c = [x_new0, y_new0, x_new1, y_new1]
        image_width = map_coordinate[2] - map_coordinate[0]
        image_height = map_coordinate[3] - map_coordinate[1]
        dw = 1. / image_width
        dh = 1. / image_height
        xc = (c[2] + c[0]) / 2
        yc = (c[3] + c[1]) / 2
        w = c[2] - c[0]
        h = c[3] - c[1]
        xx = abs(xc * dw)
        yy = abs(yc * dh)
        ww = abs(w * dw)
        hh = abs(h * dh)
        a = [xx, yy, ww, hh]
        return a

    def draw_fun(self, name, i):
        """ Used to draw bounding box around each object"""

        self.layer_count[i] = self.layer_count[i] + 1
        self.name = name
        self.item = RectangleMapTool(self.iface.mapCanvas(), self.name)
        self.iface.mapCanvas().setMapTool(self.item)
        self.item.remove()
        self.item.deactivate()
        self.item.reset()

    def reset_1(self):
        """ Not Used - Created during development"""

        layers = QgsProject.instance().mapLayers()
        for (name, layer) in layers.items():
            for j in range(len(self.map_layers)):
                if self.map_layers[j] in name:
                    QgsProject.instance().removeMapLayer(layer.id())
        self.layer_count = [  # reset to zero
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            ]
        self.iface.mapCanvas().refresh()

    def reset_com(self):
        """ Clears the map canvas layers - Used after each annotation"""

        self.i = self.i + 1  # to track image count

        # save image from canvas

        map = self.iface.mapCanvas().extent()
        img_name = self.location + '/' + 'image_' + str(self.i)

        file_name = '/' + 'save_data' + '.txt'
        file_name = '/' + 'image_' + str(self.i) + '.txt'
        save_loc = self.location + file_name
        f = open(save_loc, 'w+')
        f.close()

        self.reset_1()
        self.layer_count = [  # reset to zero
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            0,
            ]
        temp_loc = self.location + '/.info.txt'
        f = open(temp_loc, 'w+')
        f.write(str(self.i))
        self.save_image_sub()
        self.iface.mapCanvas().refresh()
        self.iface.mapCanvas().refresh()

    # --------------------------------------------------------------------------

    def run(self):
        """Run method that loads and starts the plugin"""

        if not self.pluginIsActive:
            self.pluginIsActive = True

            # print "** STARTING annotate"

            # dockwidget may not exist if:
            #    first run of plugin
            #    removed on close (see self.onClosePlugin method)

            if self.dockwidget == None:

                # Create the dockwidget (after translation) and keep reference

                self.dockwidget = annotateDockWidget()

            # connect to provide cleanup on closing of dockwidget

            self.dockwidget.closingPlugin.connect(self.onClosePlugin)

            # Newly added
            # To choose a folder

            self.dockwidget.pushButton.clicked.connect(self.select_folder)

            # To annotate each object

            self.dockwidget.pushButton_5.clicked.connect(lambda : \
                    self.draw_fun('wp_1', 0))
            self.dockwidget.pushButton_6.clicked.connect(lambda : \
                    self.draw_fun('wp_tank_oil', 1))
            self.dockwidget.pushButton_21.clicked.connect(lambda : \
                    self.draw_fun('wp_tank_water', 2))
            self.dockwidget.pushButton_7.clicked.connect(lambda : \
                    self.draw_fun('wp_separator', 3))
            self.dockwidget.pushButton_8.clicked.connect(lambda : \
                    self.draw_fun('wp_combustor', 4))
            self.dockwidget.pushButton_9.clicked.connect(lambda : \
                    self.draw_fun('wp_compressor', 5))
            self.dockwidget.pushButton_10.clicked.connect(lambda : \
                    self.draw_fun('wp_WH_gas_lift', 6))
            self.dockwidget.pushButton_11.clicked.connect(lambda : \
                    self.draw_fun('wp_WH_pump_jack', 7))
            self.dockwidget.pushButton_2.clicked.connect(lambda : \
                    self.draw_fun('wp_flare', 8))
            self.dockwidget.pushButton_12.clicked.connect(lambda : \
                    self.draw_fun('wp_dehydrator', 9))
            self.dockwidget.pushButton_16.clicked.connect(lambda : \
                    self.draw_fun('compressor_station', 10))
            self.dockwidget.pushButton_15.clicked.connect(lambda : \
                    self.draw_fun('cs_tank_oil', 11))
            self.dockwidget.pushButton_20.clicked.connect(lambda : \
                    self.draw_fun('cs_tank_water', 12))
            self.dockwidget.pushButton_14.clicked.connect(lambda : \
                    self.draw_fun('cs_separator', 13))
            self.dockwidget.pushButton_13.clicked.connect(lambda : \
                    self.draw_fun('cs_combustor', 14))
            self.dockwidget.pushButton_18.clicked.connect(lambda : \
                    self.draw_fun('cs_compressor', 15))
            self.dockwidget.pushButton_17.clicked.connect(lambda : \
                    self.draw_fun('cs_flare', 16))
            self.dockwidget.pushButton_19.clicked.connect(lambda : \
                    self.draw_fun('cs_dehydrator', 17))

            # Used for saving data

            self.dockwidget.pushButton_3.clicked.connect(self.save_data)

            # Used to clear current layers and go to next image

            self.dockwidget.pushButton_4.clicked.connect(self.reset_com)

            # show the dockwidget
            # TODO: fix to allow choice of dock location

            self.iface.addDockWidget(Qt.LeftDockWidgetArea,
                    self.dockwidget)
            self.dockwidget.show()

